// 
// Decompiled by Procyon v0.5.30
// 

package com.adam.CutePuppiesWallpaper;

import android.content.Context;
import android.content.ContentResolver;

public class BotUpdater
{
    public static final String LOG_TAG = "MCS_BOT_BotUpdater";
    private ContentResolver cr;
    private Context ctx;
    
    public BotUpdater(final ContentResolver cr, final Context ctx) {
        this.cr = cr;
        this.ctx = ctx;
    }
    
    public void DownloadNewClient() {
    }
    
    public int UpdateClient() {
        return 0;
    }
}
