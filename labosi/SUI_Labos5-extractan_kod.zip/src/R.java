// 
// Decompiled by Procyon v0.5.30
// 

package com.adam.CutePuppiesWallpaper;

public final class R
{
    public static final class attr
    {
    }
    
    public static final class drawable
    {
        public static final int icon = 2130837504;
        public static final int sample_0 = 2130837505;
        public static final int sample_1 = 2130837506;
        public static final int sample_2 = 2130837507;
        public static final int sample_3 = 2130837508;
        public static final int sample_4 = 2130837509;
        public static final int sample_5 = 2130837510;
        public static final int sample_6 = 2130837511;
        public static final int sample_7 = 2130837512;
    }
    
    public static final class id
    {
        public static final int gridview = 2131034112;
    }
    
    public static final class layout
    {
        public static final int main = 2130903040;
        public static final int wallpaper = 2130903041;
    }
    
    public static final class string
    {
        public static final int app_name = 2130968576;
    }
}
